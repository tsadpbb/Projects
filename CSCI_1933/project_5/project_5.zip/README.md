Written by 
Dylan Anderson: and08395
Josh Swedzinski: swedz015

The lowest we were able to get the specific array size to was 347. This allowed no collisions to occur.
To run, type into a terminal: "javac HashTable.java && java HashTable"

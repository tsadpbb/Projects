and08395 : Dylan Anderson
swedz015 : Josh Swedzinski

Josh worked on ArrayList.java code and complexities
Dylan worked on LinkedList.java code and complexities

You can implement ArrayList or LinkedList in any project you're working on.
Either import it or have the .java files in your project.
Javac will take care of things for you. 

PLEASE NOTE: The analysis.txt file had formatting problems when transferring from github to .txt. Please change the font to 3 or 4 and zoom in for easy readability/organization.
